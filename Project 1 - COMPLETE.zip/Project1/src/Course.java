/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public abstract class Course {

    private final String _name;
    private final int _crn;
    private final String _number;
    private final String _section;
    private final String _credit_hours;
    private final String _type;
    private final String _instructor;

    public Course(String courseName, int crnNumber, String courseNumber, String sectionNumber, String creditHours, String courseType, String instructor) {
        this._name = courseName;
        this._crn = crnNumber;
        this._number = courseNumber;
        this._section = sectionNumber;
        this._credit_hours = creditHours;
        this._type = courseType;
        this._instructor = instructor;
    }

    @Override
    public abstract String toString();

    public abstract boolean conflictsWith(Course courseToCompare);

    public String getCourseName() {
        return _name;
    }

    public int getCrnNumber() {
        return _crn;
    }

    public String getCourseNumber() {
        return _number;
    }

    public String getSectionNumber() {
        return _section;
    }

    public String getCreditHours() {
        return _credit_hours;
    }

    public String getCourseType() {
        return _type;
    }

    public String getInstructor() {
        return _instructor;
    }
}
