
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class StudentRegistrationSystem {

    public static void main(String[] args) {
        Database database = new Database("project1input.csv");
        ArrayList<Course> courses;        
        ArrayList<Course> schedule;
        schedule = new ArrayList<>();
        int menu = 0;
        courses = database.getCourses();
        Scanner scanner = new Scanner(System.in);
        while (menu != 4) {
            System.out.println("1. Search Courses");
            System.out.println("2. Register for Course");
            System.out.println("3. View Trial Schedule");
            System.out.println("4. Quit");
            System.out.print("Your choice? ");
            menu = scanner.nextInt();
            switch (menu) {
                case 1:
                    int timesFound = 0;
                    String userInput;
                    System.out.print("Enter course number in the format SSNNN (for example, CS201): ");
                    userInput = scanner.next();
                    for (Course e : courses) {
                        if (userInput.equals(e.getCourseNumber())) {
                            System.out.println(e.toString());
                            timesFound += 1;
                        }
                    }
                    if (timesFound == 0) {
                        System.out.println("Course was not Found");
                    }
                    System.out.println("\n");
                    break;
                case 2:
                    boolean conflicts;
                    conflicts = false;
                    Course wantedCourse = null;
                    System.out.print("Enter CRN Number: ");
                    int crnNum;
                    crnNum = scanner.nextInt();
                    for (Course c : courses) {
                        if (crnNum == c.getCrnNumber()) {
                            wantedCourse = c;
                        }
                    }
                    if (wantedCourse == null) {
                        System.out.println("ERROR: Either the course was not found, or it conflicts with your current schedule!");
                        break;
                    }
                    for (int i = 0; i < schedule.size(); ++i) {
                        if (wantedCourse.conflictsWith(schedule.get(i))) {
                            conflicts = true;
                            System.out.println("ERROR: Either the course was not found, or it conflicts with your current schedule!");

                        }
                    }
                    if (!conflicts) {
                        schedule.add(wantedCourse);
                        System.out.println("Course added successfully!");
                    }
                    System.out.println("\n");
                    break;
                case 3:
                    for (Course d : schedule) {
                        System.out.println(d.toString());
                    }
                    System.out.println("\n");
                    break;
                case 4:
                    System.out.println("Thanks for using the Student Registration System!");
                    break;
                default:
                    System.out.println("Invalid input");
                    break;
            }

        }
    }

}
